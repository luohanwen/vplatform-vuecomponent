import vuiPeriod from './picker/date-picker';
export default vuiPeriod;