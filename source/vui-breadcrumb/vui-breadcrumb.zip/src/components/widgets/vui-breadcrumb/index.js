import vuiBreadcrumb from './index.vue';
export default vuiBreadcrumb;